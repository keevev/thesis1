<?php 

session_start();
include 'config.php';
require_once 'libs/phpqrcode/qrlib.php'; 

if(!isset($_SESSION["user_id"])){
    header("Location:index.php");
}

if(isset($_POST["add_to_cart"]))
{
    if(isset($_SESSION["shopping_cart"]))
    {
        $item_array_id = array_column($_SESSION["shopping_cart"], "homeowner_ID");
        if(!in_array($_POST["homeowner_ID"], $item_array_id))
        {
            $count = count($_SESSION["shopping_cart"]);
            $item_array = array(
                'homeowner_ID'           =>  $_POST["homeowner_ID"],
                'last_name'         =>  $_POST["last_name"],
                'lot_number'        =>  $_POST["lot_number"],
                'block_number'     =>  $_POST["block_number"]
            );
            $_SESSION["shopping_cart"][$count] = $item_array;
        }
        else
        {
            echo '<script>alert("Homeowner Already Added")</script>';
        }
    }
    else
    {
        $item_array = array(
            'homeowner_ID'       =>  $_POST["homeowner_ID"],
            'last_name'         =>  $_POST["last_name"],
            'lot_number'        =>  $_POST["lot_number"],
            'block_number'     =>  $_POST["block_number"]
        );
        $_SESSION["shopping_cart"][0] = $item_array;

    }
}

if(isset($_GET['action']))
{
    if($_GET['action'] == "delete")
    {
        foreach($_SESSION['shopping_cart'] as $keys => $values)
        {
            if($values['homeowner_ID'] == $_GET['id'])
            {
                unset($_SESSION['shopping_cart'][$keys]);
                echo '<script>alert("Homeowner Removed")</script>';
                echo '<script>window.location="generate.php"</script>';
            }
        }
    }
}

if(isset($_GET['action']))
{
    if($_GET['action'] == "create_qr")
    {
        $homeowner=array($_SESSION["user_id"]);
        if(empty($_SESSION['shopping_cart'])){
             echo '<script>alert("no homeowner Added")</script>';
        }
        else{
        foreach($_SESSION['shopping_cart'] as $keys => $values)
        {
            array_push($homeowner, $values['homeowner_ID']);
            
        }
        echo '<script>alert("QR created")</script>';
        $location = 'temp/'.$_SESSION['user_id'].".png";

        QRcode::png(implode("  ", $homeowner),$location, 'L',10,2);
        }

         
    

    }
}




?>
<!DOCTYPE html>
<html>
    <head>
        <title>Generate QR</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.0/css/fixedHeader.bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css">

    </head>
    <body>
        <?php include 'navbar.php'?>
        <br />
        <div class="container">
            <h3 align="center">HOMEOWNERS</a></h3><br />
            <?php
                $query = "SELECT * FROM homeowners";
                $result = mysqli_query($conn, $query);
               
            ?>  
            <table id= "datatableid" class="table">
                <thead>
                    <tr>
                        <th >Name</th>
                        <th >Lot Number</th>
                        <th >Block Number</th> 
                        <th >Action</th> 

                    </tr>
                </thead>

            <?php
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_array($result))
                    {
            ?>

                <tbody>
                    <tr>
                        <form method="post" action="generate.php?action=add&id=<?php echo $row["homeowner_ID"]; ?>">
                            <td><?php echo $row["last_name"]; ?></td>
                            <td><?php echo $row["lot_number"]; ?></td>
                            <td><?php echo $row["block_number"]; ?></td>
                            <input type="hidden" name="homeowner_ID" value="<?php echo $row["homeowner_ID"]; ?>" />
                            <input type="hidden" name="last_name" value="<?php echo $row["last_name"]; ?>" />
                            <input type="hidden" name="lot_number" value="<?php echo $row["lot_number"]; ?>" />
                            <input type="hidden" name="block_number" value="<?php echo $row["block_number"]; ?>" />
                            <td><input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Visit" /></td>
                        </form>
                    </tr>
                </tbody>
            <?php
                    }
                }
            ?>
            </table>
            <script src="https://code.jquery.com/jquery-3.5.1.js"> </script>
                    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"> </script>
                    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"> </script>
                    <script src="https://cdn.datatables.net/fixedheader/3.2.0/js/dataTables.fixedHeader.min.js"> </script>
                    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"> </script>
                    <script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap.min.js"> </script>


                    <script>
                    $(document).ready(function() {
                        var table = $('#datatableid').DataTable( {
                            responsive: true
                        } );
 
                        new $.fn.dataTable.FixedHeader( table );
                    } );
                    </script>  
            
            <br />
            <h3>Visit Details</h3>  
            <div class="table-responsive">

                <table class="table table-bordered">
                    <tr>
                        <th >Name</th>
                        <th >Lot Number</th>
                        <th >Block Number</th>
                        <th >Action</th>  
                    </tr>
                    <?php
                    
                    if(!empty($_SESSION["shopping_cart"]))
                    {
                       
                        foreach($_SESSION["shopping_cart"] as $keys => $values)
                        {
                    ?>
                    <tr>
                      
                        <td><?php echo $values["last_name"]; ?></td>
                        <td><?php echo $values["lot_number"]; ?></td>
                        <td><?php echo $values["block_number"]; ?></td>

                        <td><a href="generate.php?action=delete&id=<?php echo $values["homeowner_ID"]; ?>"><span class="text-danger">Remove</span></a></td>
                        
                    </tr>
                    <?php
                            
                        }
                    }
                    ?>
                        
                </table>
                
            </div>

            
            <a href="generate.php?action=create_qr"><span class="btn btn-success">Create QR</span></a>
            <div class="qr-field">
                <h2 style="text-align:center">QR Code Result: </h2>
                <center>
                    <div class="qrframe" style="border:2px solid black; width:210px; height:210px;">
                            <?php echo '<img src="temp/'. $_SESSION['user_id'].'.png" style="width:200px; height:200px;"><br>'; ?>
                    </div>

                    <a class="btn btn-primary submitBtn" style="width:210px; margin:5px 0;" href="download.php?file=<?php echo $_SESSION['user_id']; ?>.png ">Download QR Code</a>
                </center>
            </div>

            
        </div>
    </div>

    <br />
    </body>
</html>