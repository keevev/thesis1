<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="libs/style4.css">
 

  <title></title>
</head>
<body>
  <header>
    
    <nav class="navbar">
      <ul class="nav__links">
        <li><a href="navbar.php">Welcome Visitor</a></li>
        <li><a href="generate.php">Visit Homeowners</a></li>
        <li><a href="profile.php">Profile</a></li>

        
      </ul>
    </nav>
    <a  class="cta "href="logout.php"><button>Logout</button></a>
  </header>
</body>
</html>