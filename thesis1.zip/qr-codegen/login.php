<?php 
include 'config.php';

session_start();


if (isset($_SESSION["user_id"])) {
    header("Location: navbar.php");
}
if (isset($_POST['submit'])) {
   
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql =mysqli_query($conn,"SELECT visitor_ID FROM visitor WHERE username='$username' AND password='$password'");
	

	if (mysqli_num_rows($sql)>0) {
		$row = mysqli_fetch_assoc($sql);
	    $_SESSION["user_id"]= $row['visitor_ID'];
	    header("Location:navbar.php");
	} else {   
		echo "<script>alert('Invalid')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="libs/style2.css">
	<title>Login</title>
</head>
<body>
	<div class="container">
		<form class="login-email" method="POST" >
			<p class="login-text" style="font-size:2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="text" placeholder="Username" name="username"required>	
			</div>
			<div class="input-group">
				<input type="password"  placeholder="Password" name="password" required>
				
			</div>
			<div class="input-group">
				<button class="btn" name="submit"> Login</button>
				
			</div>
			<p class="login-register-text">Don't have an account?<a href="index.php">Register here</a>.</p>
		</form>
	</div>
</body>
</html>