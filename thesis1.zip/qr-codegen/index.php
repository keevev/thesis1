<?php
include 'config.php';



?>
<!DOCTYPE html>
<html lang="en-US">
	<head>
	<title>Subdivision Registration</title>
	<link rel="stylesheet" href="libs/css/bootstrap.min.css">
	<link rel="stylesheet" href="libs/style1.css">
	
	</head>
	<body>
		<div class="myoutput">
			<h3><strong>Subdivision Registration</strong></h3>
			<div class="input-field">
				<h3>Please Fill-out All Fields</h3>
				<form method="post" action="index.php">
					<div class="form-group">
						<label>Firstname</label>
						<input type="text" class="form-control" name="first_name" style="width:20em;" placeholder="Enter your First name" value="<?php echo @$first; ?>" required />
					</div></textarea>
					<div class="form-group">
						<label>Middle Name</label>
						<input type="text" class="form-control" name="middle_name" style="width:20em;" placeholder="Enter your Middle name" value="<?php echo @$middle; ?>" required/>
					</div></textarea>
					<div class="form-group">
						<label>Lastname</label>
						<input type="text" class="form-control" name="last_name" style="width:20em;" placeholder="Enter your Last name" value="<?php echo @$last; ?>" required/>
					</div></textarea>
					<div class="form-group">
						<label>Username</label>             
						<input type="text" class="form-control" name="username" style="width:20em;" placeholder="Enter your username" value="<?php echo @$username; ?>" required />
					</div></textarea>
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" name="password" id="password" style="width:20em;" placeholder="Enter your password" value="<?php echo @$password; ?>" required />
						<td>
						<input type="checkbox" onchange="SHPassword(this);"><span id="showhidepwd">Show</span></td>
					</div></textarea>
					
					<div class="form-group">
						<label>Address</label>
						<input type="text" class="form-control" name="address" style="width:20em;" placeholder="Enter your address" value="<?php echo @$address; ?>" required />
					</div></textarea>
					<div class="form-group">
						<label>Birthdate</label>
						<input type="date" class="form-control" name="birth_date" style="width:20em;" placeholder="Enter your Birthdate" value="<?php echo @$birth; ?>" required />
					</div></textarea>
					<div class="form-group">
						<label>Mobile Number</label>
						<input type="text" class="form-control" name="number" style="width:20em;" placeholder="Enter Number with +63" value="<?php echo @$number; ?>" required />
					</div></textarea>
					<div class="form-group">
						<label>Visitor Type</label>
						<select name="visitor" class="form-control" style="width:20em;" value="<?php echo @$sex; ?> " required>
							<option value="">--Select--</option>
							<option value="1">Relative/friends</option>
							<option value="2">taxi</option>
							<option value="3">delivery</option>
						</textarea>
						</select>
					</div>
					<div class="form-group">
						<label>Sex</label>
						<select name="sex" class="form-control" style="width:20em;" value="<?php echo @$sex; ?> " required>
							<option value="">--Select--</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
						</textarea>
						</select>
					</div>
					<div class="form-group">
						<label>Plate Number</label>
						<input type="text" class="form-control" name="plateNumber" style="width:20em;" placeholder="Enter your Plate Number" value="<?php echo @$plateNumber; ?>" required />
					</div></textarea>
					
					<div class="form-group">
						
						<input type="submit" name="submit" class="btn btn-primary submitBtn" id="register" style="width:20em; margin:0;" />
						</form>

					</div>
					
				</form>
			</div>
			
		</div>
		<script type="text/javascript">
						
		function SHPassword(x){
			var chkbox=x.checked;
			if(chkbox){
				document.getElementById("password").type="text";
				document.getElementById("showhidepwd").textContent="Hide";
			}
			else{
				document.getElementById("password").type="password";
				document.getElementById("showhidepwd").textContent="Show";
			}
			}

		</script>
		
</body>
</html>

<?php
session_start();
use Twilio\Rest\Client;
$sid_key="ACa5faeccc907b8987b1283c59ded67c33"; 
$token_key="029290d3d500fce1236b171bcb224dd6";
if (isset($_POST['submit'])) {



			
			
	$_SESSION['first_name']=$_POST['first_name'];
	$_SESSION['middle_name']=$_POST['middle_name'];
	$_SESSION['last_name']=$_POST['last_name'];
	$_SESSION['username']=$_POST['username'];
	$_SESSION['password']=$_POST['password'];
	$_SESSION['address']=$_POST['address'];
	$_SESSION['birth_date']=$_POST['birth_date'];
	$_SESSION['visitor']=$_POST['visitor'];
	$_SESSION['sex']=$_POST['sex'];
	$_SESSION['plateNumber']=$_POST['plateNumber'];
	$_SESSION['number']=$_POST['number'];

	$username = $_SESSION['username'];
	$password=$_SESSION['password'];
	$number=$_SESSION['number'];
	$query1="SELECT * FROM visitor WHERE username ='$username'";
	$query3="SELECT * FROM visitor WHERE number='$number'";
	$query2="SELECT * FROM visitor WHERE password='$password'";
	$run1=mysqli_query($conn,$query1);

	$run2 =mysqli_query($conn,$query2);
	$run3 =mysqli_query($conn,$query3);
	if(mysqli_num_rows($run1) >0){
	?>
		<script>
				alert('username exists');
		</script>

		<?php
		
		exit();
	

	}
	else if (mysqli_num_rows($run2) >0) {
		?>
		<script>
				alert('password exists');
		</script>

		<?php
		
		exit();
	}
	else if (mysqli_num_rows($run3) >0) {
		?>
		<script>
				alert('number exists');
		</script>

		<?php
		
		exit();
	}
	else{

	$num=rand(1000,9999);

	$_SESSION['otp']=$num;
	$msg="Your OTP is" .$num; 
	require_once 'Twilio/autoload.php';

	

	$sid =$sid_key;
	$token=$token_key;
	$twilio= new Client($sid,$token);

	$message= $twilio->messages
					 ->create($number,
					 	array(
					 		"from" =>"+18126514132",
					 		"body" => $msg


					 	)


					 );

	header("Location:verify.php");

	}
}

?>