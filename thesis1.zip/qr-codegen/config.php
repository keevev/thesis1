<?php

$server = "db4free.net";
$user = "databasethesis1";
$pass = "databasethesis1";
$database = "databasethesis1";

$conn = mysqli_connect($server, $user, $pass, $database);






?>