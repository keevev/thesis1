<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
<style>

		div{
			text-align: center;

		}
		ul{
			 list-style: none;
			  margin: 0;
			  padding: 0;

		}
		ul li{
			margin-top: 130px;
		}
		ul li a{
			text-decoration: none;
			font-size: 20px;
			
			margin:0;
			background:darkblue;
			color: white;	

		}
	</style>
</head>
<body style="background-color:cornflowerblue">
	
		
	<div>
		
		<ul>
		  <li><a href="index.php" style="padding: 30px 92px;">Home Owner</a></li>
		  <li><a href="#" style="padding: 30px 115px">Visitors</a></li>
		  <li><a href="#" style="padding: 30px 100px;">Employees</a></li>
		

	</ul>
	</div>	

</body>
</html>