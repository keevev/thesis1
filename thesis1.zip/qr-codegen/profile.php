<?php

session_start();
if(!isset($_SESSION["user_id"])){
	header("Location:index.php");
}

include 'config.php';
if (isset($_POST["submit"])){
    $sql="UPDATE visitor SET username='$_POST[username]',password='$_POST[password]',first_name= '$_POST[first_name]',middle_name='$_POST[middle_name]',last_name='$_POST[last_name]',address='$_POST[address]',birth_date='$_POST[birth_date]',number='$_POST[number]',sex='$_POST[sex]',plateNumber='$_POST[plateNumber]' WHERE visitor_ID='{$_SESSION["user_id"]}'";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo "<script>alert('Profile Updated');</script>";
    }
    else{
        echo "<script>alert('Profile not updated');</script>";

    }
    

}


?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<title>Edit Profile</title>
</head>
<body class="profile-page">
	<?php include 'navbar.php'?>
	<div class="container">
		<h2 align="center">Profile</h2>
		<form action="" method="post" enctype="multipart/form-data" style="width: 500px; margin: auto;">
			<?php
			$sql=("SELECT * FROM visitor WHERE visitor_ID='{$_SESSION["user_id"]}'");
			$result = mysqli_query($conn,$sql);
			if(mysqli_num_rows($result)>0){
				while ($row=mysqli_fetch_assoc($result)) {
			?>
			
			<div class="form-group">
				<label for="first_name">First Name</label>

				<input type="text" class="form-control"id="first_name"  name="first_name" value="<?php echo $row['first_name'];?>"required>
			</div>
			<div class="form-group">
				<label for="middle_name">Middle Name</label>

				<input type="text" class="form-control"id="middle_name"  name="middle_name" value="<?php echo $row['middle_name'];?>"required>
			</div>
			<div class="form-group">
				<label for="last_name">Last Name</label>

				<input type="text" class="form-control"id="last_name"  name="last_name" value="<?php echo $row['last_name'];?>"required>
			</div>
			<div class="form-group">
				<label for="username">Username</label>

				<input type="text" class="form-control"id="username"name="username" value="<?php echo $row['username'];?>" required>
			</div>
			<div class="form-group">
				<label for="password">Password</label>

				<input type="password"class="form-control" id="password"name="password"  value="<?php echo $row['password'];?>"required>
				<input type="checkbox" onchange="SHPassword(this);"><span id="showhidepwd">Show</span></td>
			</div>
			<div class="form-group">
				<label for="address">Address</label>

				<input type="text" class="form-control"id="address"name="address" value="<?php echo $row['address'];?>"required>
			</div>
			<div class="form-group">
				<label for="birth_date">Birthdate</label>

				<input type="date" class="form-control"id="birth_date"name="birth_date"value="<?php echo $row['birth_date'];?>"required>
			</div>
			<div class="form-group">
				<label for="number">Mobile Number</label>
				
				<input type="number"class="form-control" id="number"name="number"value="<?php echo $row['number'];?>"required>
			</div>
			<div class="form-group">
				<label for="sex">Sex</label>

				<input type="text"class="form-control" id="sex"name="sex" value="<?php echo $row['sex'];?>" required>
			</div>
			<div class="form-group">
				<label for="plateNumber">Plate number</label>

				<input type="text" class="form-control"id="plateNumber"name="plateNumber"  value="<?php echo $row['plateNumber'];?>"required>
			</div>
			<?php
					
				}
			}

			?>
			<div>
				<button type="submit" name="submit"class="btn" >Update Profile</button>
			</div>
			
	</div>
	<script type="text/javascript">
						
		function SHPassword(x){
			var chkbox=x.checked;
			if(chkbox){
				document.getElementById("password").type="text";
				document.getElementById("showhidepwd").textContent="Hide";
			}
			else{
				document.getElementById("password").type="password";
				document.getElementById("showhidepwd").textContent="Show";
			}
			}

		</script>
		</body>

</html>